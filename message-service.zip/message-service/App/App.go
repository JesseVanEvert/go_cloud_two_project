package app

import (
	"fmt"
)

func Start() {
	fmt.Println("Starting App in app package")
}
